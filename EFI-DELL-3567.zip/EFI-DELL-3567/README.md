# Dell-3567-hackintosh
Dell Inspiron 15 3567 (Opencore 0.6.1) compatible with macOS 10.15.6

# Specs:
- Model: Dell Inspiron 15 3567
- CPU: 2.4 GHz Dual-Core Intel Core i3
- GPU: Intel HD Graphics 620 2048 MB
- RAM: 8GB
- Ethernet: RTL810xE
- Wifi: Intel AC 3165
- Audio Codec : Realtek ALC256 (ALC3246)

# What doesn't work:
- WiFi
